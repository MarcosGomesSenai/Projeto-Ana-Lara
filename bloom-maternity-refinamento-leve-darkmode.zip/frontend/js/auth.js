(function () {
  "use strict";
  function qs(s, scope = document) { return scope.querySelector(s); }
  function initAuthForms() {
    document.querySelectorAll("[data-auth-form]").forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        if (!form.checkValidity()) {
          form.classList.add("was-validated");
          window.showBloomToast?.("Confira os dados informados.", "bi-exclamation-circle");
          return;
        }
        const data = Object.fromEntries(new FormData(form).entries());
        localStorage.setItem("bloom_user", JSON.stringify({ nome: data.nome || data.email?.split("@")[0] || "Paciente", email: data.email }));
        localStorage.setItem("bloom_token", `demo_${Date.now()}`);
        window.showBloomToast?.("Acesso demo realizado. Em produção, conecte ao back-end da pasta backend.");
      });
    });
  }
  function initAdmin() {
    const mount = qs("[data-render='admin-demo']");
    if (!mount) return;
    const items = JSON.parse(localStorage.getItem("bloom_agendamentos_demo") || "[]");
    mount.innerHTML = items.length ? items.slice(-8).reverse().map((item) => `
      <tr><td data-label="Paciente"><strong>${item.nome}</strong><br><span class="small table-description">${item.email}</span></td><td data-label="Exame">${item.exame}</td><td data-label="Data">${item.data} às ${item.horario}</td><td data-label="Status"><span class="badge-soft">Demo</span></td></tr>
    `).join("") : `<tr><td colspan="4" class="text-center py-4">Nenhum agendamento demo salvo ainda.</td></tr>`;
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => { initAuthForms(); initAdmin(); });
  else { initAuthForms(); initAdmin(); }
})();
