(function () {
  "use strict";
  const qs = (s, scope = document) => scope.querySelector(s);
  const doctors = () => window.BloomData?.doctors || [];
  const exams = () => window.BloomData?.exams || [];

  function fillSelects() {
    const doctorSelect = qs("#medico");
    const examSelect = qs("#exame");
    if (doctorSelect) {
      const selected = new URLSearchParams(window.location.search).get("medico");
      doctorSelect.innerHTML = `<option value="">Selecione uma especialista</option>` + doctors().map((d) => `<option value="${d.id}" ${String(d.id) === selected ? "selected" : ""}>${d.name} — ${d.specialty}</option>`).join("");
    }
    if (examSelect) {
      examSelect.innerHTML = `<option value="">Selecione consulta ou exame</option>` + exams().map((e) => `<option value="${e.name}">${e.name} — ${e.price}</option>`).join("");
    }
  }

  function initAppointment() {
    const form = qs("#appointmentForm");
    if (!form) return;
    fillSelects();
    const today = new Date();
    today.setDate(today.getDate() + 1);
    qs("#data")?.setAttribute("min", today.toISOString().slice(0, 10));
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!form.checkValidity()) {
        form.classList.add("was-validated");
        window.showBloomToast?.("Preencha os campos obrigatórios para simular o agendamento.", "bi-exclamation-circle");
        return;
      }
      const data = Object.fromEntries(new FormData(form).entries());
      const list = JSON.parse(localStorage.getItem("bloom_agendamentos_demo") || "[]");
      list.push({ ...data, id: Date.now(), criadoEm: new Date().toISOString() });
      localStorage.setItem("bloom_agendamentos_demo", JSON.stringify(list));
      form.reset();
      form.classList.remove("was-validated");
      window.showBloomToast?.("Agendamento simulado salvo no navegador. Integre ao back-end para envio real.");
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initAppointment);
  else initAppointment();
})();
