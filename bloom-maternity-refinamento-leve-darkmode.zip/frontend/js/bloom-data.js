window.BloomData = {
  doctors: [
    {
      id: 1,
      name: "Dra. Mariana Costa Ferreira",
      specialty: "Obstetrícia e Parto Humanizado",
      category: "obstetricia",
      crm: "CRM 181654-SP",
      rating: 5.0,
      reviews: 156,
      years: 15,
      image: "../assets/images/dra-mariana-costa-ferreira.png",
      summary: "Pré-natal humanizado, parto normal, puerpério e amamentação com acompanhamento acolhedor.",
      formation: "Medicina pela PUC-SP, residência na Santa Casa de São Paulo e certificação em assistência ao parto humanizado.",
      tags: ["Pré-natal", "Parto humanizado", "Puerpério"]
    },
    {
      id: 2,
      name: "Dra. Ana Carolina Mendes",
      specialty: "Ginecologia e Obstetrícia",
      category: "ginecologia",
      crm: "CRM 154789-SP",
      rating: 4.9,
      reviews: 142,
      years: 11,
      image: "../assets/images/dra-ana-carolina-mendes.png",
      summary: "Cuidado integral em saúde feminina, contracepção, pré-natal e prevenção ginecológica.",
      formation: "Medicina pela USP, residência no Hospital das Clínicas e título FEBRASGO/AMB.",
      tags: ["Saúde da mulher", "Contracepção", "Rotina ginecológica"]
    },
    {
      id: 3,
      name: "Dr. Ricardo Almeida Costa",
      specialty: "Medicina Fetal e Ultrassonografia",
      category: "medicina-fetal",
      crm: "CRM 132456-SP",
      rating: 4.8,
      reviews: 95,
      years: 10,
      image: "../assets/images/dr-ricardo-almeida-costa.png",
      summary: "Ultrassom morfológico, diagnóstico pré-natal avançado e gestação de alto risco.",
      formation: "Medicina pela UNICAMP, residência em Ginecologia e Obstetrícia e fellowship em Medicina Fetal.",
      tags: ["Medicina fetal", "Morfológico", "Alto risco"]
    },
    {
      id: 4,
      name: "Dra. Fernanda Ribeiro Alves",
      specialty: "Fertilidade e Ginecologia Endócrina",
      category: "fertilidade",
      crm: "CRM 149876-SP",
      rating: 4.9,
      reviews: 87,
      years: 8,
      image: "../assets/images/dra-fernanda-ribeiro-alves.png",
      summary: "Infertilidade, hormônios femininos, menopausa e planejamento reprodutivo personalizado.",
      formation: "Medicina pela UNIFESP e pós-graduação em Reprodução Humana.",
      tags: ["Fertilidade", "Hormônios", "Menopausa"]
    },
    {
      id: 5,
      name: "Dr. Gustavo Henrique Martins",
      specialty: "Reprodução Humana",
      category: "fertilidade",
      crm: "CRM 145987-SP",
      rating: 4.9,
      reviews: 128,
      years: 12,
      image: "../assets/images/dr-gustavo-henrique-martins.png",
      summary: "Fertilidade do casal, inseminação artificial, FIV e investigação da infertilidade.",
      formation: "Medicina pela USP e especialização em Reprodução Assistida.",
      tags: ["FIV", "Inseminação", "Casais"]
    }
  ],
  exams: [
    { icon: "bi-soundwave", name: "Ultrassom Obstétrico", category: "Ultrassonografia", duration: "30 min", result: "24h úteis", price: "R$ 250", desc: "Acompanhamento do desenvolvimento gestacional e vitalidade fetal." },
    { icon: "bi-baby", name: "Morfológico 1º Trimestre", category: "Medicina fetal", duration: "45 min", result: "24h úteis", price: "R$ 380", desc: "Avaliação anatômica inicial, translucência nucal e rastreios importantes." },
    { icon: "bi-heart-pulse", name: "Morfológico 2º Trimestre", category: "Medicina fetal", duration: "45 min", result: "24h úteis", price: "R$ 380", desc: "Exame detalhado da anatomia fetal no período ideal da gestação." },
    { icon: "bi-badge-3d", name: "Ultrassom 3D/4D", category: "Imagem", duration: "40 min", result: "24h úteis", price: "R$ 450", desc: "Imagens tridimensionais e movimentos do bebê com experiência memorável." },
    { icon: "bi-droplet-half", name: "Hemograma Completo", category: "Análise clínica", duration: "15 min", result: "24h úteis", price: "R$ 60", desc: "Avaliação laboratorial essencial para rotina ginecológica e gestacional." },
    { icon: "bi-activity", name: "Curva Glicêmica", category: "Gestação", duration: "120 min", result: "48h úteis", price: "R$ 90", desc: "Rastreamento de diabetes gestacional com orientação completa." },
    { icon: "bi-clipboard2-pulse", name: "Cardiotocografia", category: "Cardiologia fetal", duration: "30 min", result: "Imediato", price: "R$ 200", desc: "Monitoramento dos batimentos fetais e contrações uterinas." },
    { icon: "bi-shield-check", name: "Preventivo Papanicolau", category: "Ginecologia", duration: "15 min", result: "7 dias úteis", price: "R$ 80", desc: "Rastreamento preventivo do câncer do colo do útero." }
  ],
  testimonials: [
    { name: "Camila R.", text: "A clínica passa segurança desde a recepção. O pré-natal foi cuidadoso, humano e muito organizado.", note: "Pré-natal" },
    { name: "Juliana M.", text: "Fiz o morfológico e recebi explicações claras durante todo o exame. Ambiente lindo e acolhedor.", note: "Ultrassom" },
    { name: "Renata S.", text: "A telemedicina me ajudou muito no puerpério. Fui atendida rápido e com muita atenção.", note: "Telemedicina" }
  ],
  faqs: [
    { q: "A clínica atende apenas gestantes?", a: "Não. Atendemos saúde da mulher em diferentes fases: rotina ginecológica, fertilidade, contracepção, pré-natal, parto, puerpério, climatério e menopausa." },
    { q: "Consigo agendar exames e consulta no mesmo dia?", a: "Sim, quando há disponibilidade. O formulário de agendamento permite selecionar especialidade, profissional, data e tipo de atendimento." },
    { q: "O dark mode altera a leitura dos exames e tabelas?", a: "Não. A interface foi refatorada com variáveis específicas para tema claro e escuro, mantendo contraste adequado em cards, formulários, tabelas e menus." },
    { q: "A telemedicina substitui consulta presencial?", a: "Ela é indicada para orientações, retornos, avaliação inicial e acompanhamento. Exames físicos e procedimentos continuam sendo presenciais." }
  ]
};
