# Bloom Maternity — Refatoração Premium

## O que foi reconstruído

Esta versão refaz a experiência visual e técnica do front-end da clínica com foco em:

- landing page premium para obstetrícia, ginecologia, maternidade e saúde da mulher;
- dark mode real com variáveis CSS e contraste adequado em textos, cards, formulários e tabelas;
- navbar sticky, loading elegante, reveal on scroll, hover states e microinterações suaves;
- cards de exames e especialistas com hierarquia visual, sombras e espaçamentos consistentes;
- tabelas responsivas que viram blocos legíveis no celular;
- novas seções: diferenciais, depoimentos, FAQ, parceiros, contato rápido, mapa/unidades, telemedicina, newsletter e agendamento;
- código organizado em HTML semântico, CSS moderno, Bootstrap 5 e JavaScript modular.

## Arquivos principais alterados

```text
index.html                              # redireciona para o front-end, evitando listagem de pasta
frontend/index.html                     # redireciona para pages/index.html
frontend/pages/*.html                   # páginas refeitas visualmente
frontend/css/main.css                   # tema completo claro/escuro + componentes + responsividade
frontend/js/main.js                     # layout, tema, animações, filtros, toasts, FAQ e conteúdo dinâmico
frontend/js/bloom-data.js               # dados locais de médicos, exames, FAQ e depoimentos
frontend/js/agendamento.js              # formulário de agendamento demo
frontend/js/medicos.js                  # detalhe do médico por ID
frontend/js/auth.js                     # login/cadastro/admin demo
frontend/assets/images/logo-bloom-*.svg # logos para fundo claro e escuro
backend/database/script.sql             # corrigido índice inválido em exames
```

## Como rodar o front-end

### Opção 1 — Live Server
Abra a pasta do projeto no VS Code e execute o Live Server no arquivo:

```text
index.html
```

Ele redireciona automaticamente para:

```text
frontend/pages/index.html
```

### Opção 2 — Apache/XAMPP
Copie a pasta do projeto para `htdocs` e acesse a raiz da pasta pelo navegador. O `index.html` da raiz evita aparecer a listagem de diretórios.

## Como rodar o back-end Node/MySQL já existente

```bash
cd backend
npm install
npm start
```

Depois execute no MySQL:

```text
backend/database/script.sql
```

> Correção aplicada: o índice `idx_tipo_usuario` foi removido da tabela `exames`, porque a coluna `tipo_usuario` pertence à tabela `pacientes`, não à tabela `exames`.

## Observação importante

Os formulários do front-end estão preparados com validação e feedback visual. Nesta entrega, eles salvam dados de demonstração no navegador quando aplicável. Para produção, conecte os envios às rotas do back-end em `backend/routes`.
