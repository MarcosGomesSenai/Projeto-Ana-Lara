# Bloom Maternity — Refinamento leve de dark mode e imagens

Este pacote mantém o mesmo layout, a mesma estrutura e a mesma identidade visual do projeto original. As alterações foram pontuais, focadas em legibilidade, contraste e acabamento visual.

## Ajustes realizados

- Dark mode refinado com variáveis CSS específicas para fundos, superfícies, campos, cards, tabelas, bordas e textos.
- Contraste corrigido em cards, botões, badges, tabelas, formulário, navbar, dropdown, accordion e textos auxiliares.
- Correção de textos claros em áreas translúcidas, especialmente no painel principal da home.
- Logo recebeu ajustes de sombra, brilho e contraste no tema escuro, sem troca da marca.
- Foram adicionadas ilustrações SVG locais e leves para páginas internas: agendamento, serviços, especialistas, telemedicina, unidades, planos, login, cadastro, dúvidas e admin.
- Mapa/unidade recebeu imagem vetorial local de apoio visual, mantendo a estrutura existente.
- Tabelas receberam melhor leitura no tema escuro, linhas alternadas e hover mais suave.
- Cards receberam hover mais refinado, bordas e sombras mais elegantes.
- Formulários receberam melhor contraste de inputs, foco e estados de validação.
- Mantidas as cores principais: rosa, lilás, branco e azul escuro.
- Mantidos HTML, CSS e JS puros, sem troca de tecnologia.

## Validações feitas

- Sintaxe dos arquivos JavaScript do front-end e back-end validada com `node --check`.
- Conferência básica de links locais, scripts, CSS e imagens locais usadas nas páginas HTML.
- Conferência de URLs locais dentro do CSS.

## Observação

Não houve reformulação completa. O objetivo foi apenas deixar o projeto mais legível, premium e consistente no modo claro/escuro.
