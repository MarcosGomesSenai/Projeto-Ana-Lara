(function () {
  "use strict";
  function qs(s, scope = document) { return scope.querySelector(s); }
  function params() { return new URLSearchParams(window.location.search); }
  function renderDetail() {
    const mount = qs("[data-render='doctor-detail']");
    if (!mount) return;
    const id = Number(params().get("id") || params().get("medico") || 1);
    const doctors = window.BloomData?.doctors || [];
    const doc = doctors.find((item) => item.id === id) || doctors[0];
    if (!doc) return;
    mount.innerHTML = `
      <section class="page-hero">
        <div class="container-xl">
          <div class="row g-5 align-items-center">
            <div class="col-lg-6" data-reveal>
              <span class="eyebrow"><i class="bi bi-person-heart"></i> ${doc.specialty}</span>
              <h1 class="page-title mb-4">${doc.name}</h1>
              <p class="lead-soft">${doc.summary}</p>
              <div class="d-flex flex-wrap gap-2 my-4">
                <span class="badge-soft"><i class="bi bi-award"></i>${doc.crm}</span>
                <span class="badge-soft"><i class="bi bi-star-fill"></i>${doc.rating.toFixed(1)} · ${doc.reviews} avaliações</span>
                <span class="badge-soft"><i class="bi bi-clock-history"></i>${doc.years}+ anos</span>
              </div>
              <div class="d-flex flex-wrap gap-3">
                <a class="btn btn-premium px-4" href="agendamento.html?medico=${doc.id}"><i class="bi bi-calendar-heart me-2"></i>Agendar com especialista</a>
                <a class="btn btn-soft px-4" href="medicos.html"><i class="bi bi-arrow-left me-2"></i>Voltar</a>
              </div>
            </div>
            <div class="col-lg-5 offset-lg-1" data-reveal>
              <article class="doctor-card overflow-hidden">
                <div class="doctor-photo"><img src="${doc.image}" alt="${doc.name}"></div>
                <div class="card-pad">
                  <h2 class="h4 fw-black">Formação e atuação</h2>
                  <p>${doc.formation}</p>
                  <div class="d-flex flex-wrap gap-2">${doc.tags.map((tag) => `<span class="badge-soft">${tag}</span>`).join("")}</div>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container-xl">
          <div class="row g-4">
            <div class="col-lg-4"><article class="feature-card card-pad h-100"><div class="icon-bubble mb-3"><i class="bi bi-heart-pulse"></i></div><h3 class="h5 fw-black">Atendimento humanizado</h3><p>Consulta com escuta ativa, explicações claras e plano de cuidado individualizado.</p></article></div>
            <div class="col-lg-4"><article class="feature-card card-pad h-100"><div class="icon-bubble mb-3"><i class="bi bi-shield-check"></i></div><h3 class="h5 fw-black">Protocolos seguros</h3><p>Fluxos organizados para pré-natal, exames, retornos e acompanhamento contínuo.</p></article></div>
            <div class="col-lg-4"><article class="feature-card card-pad h-100"><div class="icon-bubble mb-3"><i class="bi bi-camera-video"></i></div><h3 class="h5 fw-black">Retorno presencial ou online</h3><p>Quando indicado, os retornos podem ser realizados por telemedicina.</p></article></div>
          </div>
        </div>
      </section>`;
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", renderDetail);
  else renderDetail();
})();
