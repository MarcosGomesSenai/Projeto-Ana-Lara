(function () {
  "use strict";

  const page = document.body?.dataset?.page || "";
  const root = document.documentElement;
  const storageKey = "bloom_theme";

  const qs = (selector, scope = document) => scope.querySelector(selector);
  const qsa = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));

  function getBasePrefix() {
    const path = window.location.pathname.replace(/\\/g, "/");
    return path.includes("/frontend/pages/") || path.endsWith("/pages/index.html") ? "" : "frontend/pages/";
  }

  function assetPrefix() {
    const path = window.location.pathname.replace(/\\/g, "/");
    return path.includes("/frontend/pages/") || path.includes("/pages/") ? ".." : "frontend";
  }

  function applyTheme(theme) {
    const nextTheme = theme === "dark" ? "dark" : "light";
    root.setAttribute("data-theme", nextTheme);
    localStorage.setItem(storageKey, nextTheme);
    qsa("[data-theme-toggle]").forEach((btn) => {
      btn.setAttribute("aria-label", nextTheme === "dark" ? "Ativar tema claro" : "Ativar tema escuro");
      btn.innerHTML = nextTheme === "dark" ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon-stars"></i>';
    });
  }

  function initTheme() {
    const saved = localStorage.getItem(storageKey);
    const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    applyTheme(saved || (prefersDark ? "dark" : "light"));
  }

  function navLink(href, label, icon, id) {
    const active = page === id ? "active" : "";
    return `<li class="nav-item"><a class="nav-link ${active}" href="${href}"><i class="bi ${icon} me-1"></i>${label}</a></li>`;
  }

  function renderNavbar() {
    const mount = qs("#site-navbar");
    if (!mount) return;
    const p = getBasePrefix();
    const a = assetPrefix();
    mount.innerHTML = `
      <a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
      <nav class="navbar navbar-expand-lg site-navbar" aria-label="Navegação principal">
        <div class="container-xl">
          <a class="navbar-brand d-flex align-items-center" href="${p}index.html" aria-label="Bloom Maternity - início">
            <img src="${a}/assets/images/logo-bloom-light.svg" class="logo-light" alt="Bloom Maternity">
            <img src="${a}/assets/images/logo-bloom-dark.svg" class="logo-dark" alt="Bloom Maternity">
          </a>
          <div class="d-flex gap-2 align-items-center order-lg-3">
            <button class="theme-toggle" type="button" data-theme-toggle aria-label="Alternar tema"><i class="bi bi-moon-stars"></i></button>
            <a class="btn btn-premium d-none d-md-inline-flex px-4" href="${p}agendamento.html"><i class="bi bi-calendar-heart me-2"></i>Agendar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarPremium" aria-controls="navbarPremium" aria-expanded="false" aria-label="Abrir menu">
              <span class="navbar-toggler-icon"></span>
            </button>
          </div>
          <div class="collapse navbar-collapse" id="navbarPremium">
            <ul class="navbar-nav mx-auto align-items-lg-center gap-lg-1 py-3 py-lg-0">
              ${navLink(`${p}index.html`, "Início", "bi-house-heart", "home")}
              ${navLink(`${p}servicos.html`, "Serviços", "bi-clipboard2-pulse", "servicos")}
              ${navLink(`${p}medicos.html`, "Especialistas", "bi-people", "medicos")}
              ${navLink(`${p}telemedicina.html`, "Telemedicina", "bi-camera-video", "telemedicina")}
              ${navLink(`${p}unidades.html`, "Unidades", "bi-geo-alt", "unidades")}
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle ${["planos","duvidas","login","cadastro","admin"].includes(page) ? "active" : ""}" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-grid me-1"></i>Mais</a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="${p}planos.html"><i class="bi bi-credit-card me-2"></i>Planos</a></li>
                  <li><a class="dropdown-item" href="${p}duvidas.html"><i class="bi bi-question-circle me-2"></i>Dúvidas frequentes</a></li>
                  <li><a class="dropdown-item" href="${p}login.html"><i class="bi bi-person-lock me-2"></i>Área do paciente</a></li>
                  <li><a class="dropdown-item" href="${p}admin.html"><i class="bi bi-speedometer2 me-2"></i>Painel admin</a></li>
                </ul>
              </li>
            </ul>
            <div class="d-lg-none d-grid gap-2">
              <a class="btn btn-premium" href="${p}agendamento.html"><i class="bi bi-calendar-heart me-2"></i>Agendar consulta</a>
              <a class="btn btn-soft" href="${p}login.html"><i class="bi bi-box-arrow-in-right me-2"></i>Entrar</a>
            </div>
          </div>
        </div>
      </nav>`;
  }

  function renderFooter() {
    const mount = qs("#site-footer");
    if (!mount) return;
    const p = getBasePrefix();
    const a = assetPrefix();
    mount.innerHTML = `
      <footer class="site-footer">
        <div class="container-xl">
          <div class="row g-4">
            <div class="col-lg-4">
              <img src="${a}/assets/images/logo-bloom-dark.svg" alt="Bloom Maternity" style="width:220px" class="mb-3">
              <p>Clínica premium de obstetrícia e ginecologia com atendimento humanizado, tecnologia médica e jornada completa para mulheres e famílias.</p>
              <div class="d-flex gap-2 mt-3">
                <a class="social-btn" href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
                <a class="social-btn" href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
                <a class="social-btn" href="#" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
                <a class="social-btn" href="#" aria-label="YouTube"><i class="bi bi-youtube"></i></a>
              </div>
            </div>
            <div class="col-6 col-lg-2">
              <h3 class="h6 footer-title">Navegação</h3>
              <ul class="list-unstyled d-grid gap-2">
                <li><a href="${p}index.html">Início</a></li>
                <li><a href="${p}servicos.html">Serviços</a></li>
                <li><a href="${p}medicos.html">Especialistas</a></li>
                <li><a href="${p}agendamento.html">Agendamento</a></li>
              </ul>
            </div>
            <div class="col-6 col-lg-2">
              <h3 class="h6 footer-title">Cuidado</h3>
              <ul class="list-unstyled d-grid gap-2">
                <li><a href="${p}telemedicina.html">Telemedicina</a></li>
                <li><a href="${p}planos.html">Planos</a></li>
                <li><a href="${p}unidades.html">Unidades</a></li>
                <li><a href="${p}duvidas.html">FAQ</a></li>
              </ul>
            </div>
            <div class="col-lg-4">
              <h3 class="h6 footer-title">Contato rápido</h3>
              <ul class="list-unstyled d-grid gap-2 mb-4">
                <li><i class="bi bi-telephone me-2 text-warning"></i>(11) 3333-4444</li>
                <li><i class="bi bi-whatsapp me-2 text-success"></i>(11) 99999-9999</li>
                <li><i class="bi bi-envelope me-2 text-info"></i>contato@bloommaternity.com.br</li>
                <li><i class="bi bi-clock-history me-2 text-light"></i>Seg-Sex: 8h às 20h · Sáb: 8h às 14h</li>
              </ul>
              <form class="newsletter-form" novalidate>
                <label class="form-label text-white" for="footerEmail">Receba dicas de saúde feminina</label>
                <div class="input-group">
                  <input id="footerEmail" type="email" class="form-control" placeholder="Seu e-mail" required>
                  <button class="btn btn-premium" type="submit">Assinar</button>
                </div>
              </form>
            </div>
          </div>
          <div class="footer-bottom d-flex flex-column flex-md-row justify-content-between gap-2">
            <small>© 2026 Bloom Maternity. Todos os direitos reservados.</small>
            <small>Privacidade · LGPD · Termos de uso</small>
          </div>
        </div>
      </footer>`;
  }

  function initNavbarEffects() {
    const nav = qs(".site-navbar");
    const onScroll = () => nav?.classList.toggle("is-scrolled", window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  function initReveal() {
    const elements = qsa("[data-reveal]");
    if (!elements.length) return;
    if (!("IntersectionObserver" in window)) {
      elements.forEach((el) => el.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    elements.forEach((el, idx) => {
      el.style.transitionDelay = `${Math.min(idx % 4, 3) * 80}ms`;
      observer.observe(el);
    });
  }

  function initToasts() {
    if (window.showBloomToast) return;
    const toast = document.createElement("div");
    toast.className = "bloom-toast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");
    document.body.appendChild(toast);
    window.showBloomToast = function (message, icon = "bi-check-circle") {
      toast.innerHTML = `<div class="d-flex align-items-start gap-2"><i class="bi ${icon} text-gradient fs-4"></i><div>${message}</div></div>`;
      toast.classList.add("show");
      clearTimeout(window.__bloomToastTimeout);
      window.__bloomToastTimeout = setTimeout(() => toast.classList.remove("show"), 3600);
    };
  }

  function initNewsletter() {
    qsa(".newsletter-form").forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        const input = qs("input[type=email]", form);
        if (!input || !input.checkValidity()) {
          input?.classList.add("is-invalid");
          showBloomToast("Digite um e-mail válido para assinar a newsletter.", "bi-exclamation-circle");
          return;
        }
        input.classList.remove("is-invalid");
        input.value = "";
        showBloomToast("Cadastro realizado! Você receberá conteúdos selecionados da Bloom.");
      });
    });
  }

  function initThemeButtons() {
    qsa("[data-theme-toggle]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const current = root.getAttribute("data-theme") === "dark" ? "dark" : "light";
        applyTheme(current === "dark" ? "light" : "dark");
      });
    });
  }

  function initLoader() {
    const loader = qs("#pageLoader");
    if (!loader) return;
    document.body.classList.add("is-loading");
    window.addEventListener("load", () => {
      setTimeout(() => {
        loader.classList.add("is-hidden");
        document.body.classList.remove("is-loading");
      }, 180);
    });
  }

  function cardExam(exam) {
    return `
      <article class="service-card card-pad h-100" data-reveal>
        <div class="icon-bubble mb-4"><i class="bi ${exam.icon}"></i></div>
        <div class="d-flex justify-content-between gap-3 align-items-start mb-2">
          <h3 class="h5 fw-black mb-0">${exam.name}</h3>
          <span class="badge-soft">${exam.price}</span>
        </div>
        <p>${exam.desc}</p>
        <div class="service-meta">
          <span class="badge-soft"><i class="bi bi-tag"></i>${exam.category}</span>
          <span class="badge-soft"><i class="bi bi-clock"></i>${exam.duration}</span>
          <span class="badge-soft"><i class="bi bi-file-earmark-check"></i>${exam.result}</span>
        </div>
      </article>`;
  }

  function doctorCard(doc) {
    return `
      <article class="doctor-card d-flex flex-column" data-category="${doc.category}" data-reveal>
        <div class="doctor-photo">
          <img src="${doc.image}" alt="${doc.name}" loading="lazy">
        </div>
        <div class="card-pad d-flex flex-column flex-grow-1">
          <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
            <div>
              <h3 class="h5 fw-black mb-1">${doc.name}</h3>
              <p class="small mb-0">${doc.specialty}</p>
            </div>
            <span class="rating"><i class="bi bi-star-fill"></i>${doc.rating.toFixed(1)}</span>
          </div>
          <p>${doc.summary}</p>
          <div class="d-flex flex-wrap gap-2 my-3">${doc.tags.map((tag) => `<span class="badge-soft">${tag}</span>`).join("")}</div>
          <div class="doctor-actions d-flex gap-2 flex-wrap">
            <a class="btn btn-soft flex-fill" href="medico-detalhe.html?id=${doc.id}">Perfil</a>
            <a class="btn btn-premium flex-fill" href="agendamento.html?medico=${doc.id}">Agendar</a>
          </div>
        </div>
      </article>`;
  }

  function renderDynamicContent() {
    const data = window.BloomData || {};
    const examsMount = qs("[data-render='exams']");
    if (examsMount) {
      const limit = Number(examsMount.dataset.limit || data.exams?.length || 0);
      examsMount.innerHTML = (data.exams || []).slice(0, limit).map(cardExam).join("");
    }
    const examsTable = qs("[data-render='exams-table']");
    if (examsTable) {
      examsTable.innerHTML = (data.exams || []).map((exam) => `
        <tr>
          <td data-label="Exame"><strong>${exam.name}</strong><br><span class="small text-muted">${exam.desc}</span></td>
          <td data-label="Categoria">${exam.category}</td>
          <td data-label="Duração">${exam.duration}</td>
          <td data-label="Resultado">${exam.result}</td>
          <td data-label="Valor"><span class="badge-soft">${exam.price}</span></td>
        </tr>`).join("");
    }
    const doctorsMount = qs("[data-render='doctors']");
    if (doctorsMount) {
      const limit = Number(doctorsMount.dataset.limit || data.doctors?.length || 0);
      doctorsMount.innerHTML = (data.doctors || []).slice(0, limit).map(doctorCard).join("");
    }
    const testimonialsMount = qs("[data-render='testimonials']");
    if (testimonialsMount) {
      testimonialsMount.innerHTML = (data.testimonials || []).map((item) => `
        <article class="testimonial-card card-pad h-100" data-reveal>
          <div class="rating mb-3"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></div>
          <p class="fs-5">“${item.text}”</p>
          <div class="d-flex justify-content-between align-items-center mt-4">
            <strong>${item.name}</strong><span class="badge-soft">${item.note}</span>
          </div>
        </article>`).join("");
    }
    const faqMount = qs("[data-render='faq']");
    if (faqMount) {
      faqMount.innerHTML = (data.faqs || []).map((item, index) => `
        <div class="accordion-item" data-reveal>
          <h2 class="accordion-header" id="faqHeading${index}">
            <button class="accordion-button ${index ? "collapsed" : ""}" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapse${index}" aria-expanded="${index ? "false" : "true"}" aria-controls="faqCollapse${index}">
              ${item.q}
            </button>
          </h2>
          <div id="faqCollapse${index}" class="accordion-collapse collapse ${index ? "" : "show"}" aria-labelledby="faqHeading${index}" data-bs-parent="#faqAccordion">
            <div class="accordion-body">${item.a}</div>
          </div>
        </div>`).join("");
    }
  }

  function initFilters() {
    const filterGroups = qsa("[data-filter-group]");
    filterGroups.forEach((group) => {
      group.addEventListener("click", (event) => {
        const btn = event.target.closest("[data-filter]");
        if (!btn) return;
        const targetSelector = group.dataset.target;
        const value = btn.dataset.filter;
        qsa("[data-filter]", group).forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        qsa(targetSelector).forEach((item) => {
          const match = value === "all" || item.dataset.category === value;
          item.closest(".col")?.classList.toggle("d-none", !match);
          item.classList.toggle("d-none", !match);
        });
      });
    });
  }

  function initQuickForms() {
    qsa("[data-demo-form]").forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        if (!form.checkValidity()) {
          form.classList.add("was-validated");
          showBloomToast("Revise os campos obrigatórios antes de continuar.", "bi-exclamation-circle");
          return;
        }
        form.reset();
        form.classList.remove("was-validated");
        showBloomToast("Solicitação registrada com sucesso. Em um projeto real, ela seria enviada ao back-end.");
      });
    });
  }

  function init() {
    initTheme();
    renderNavbar();
    renderFooter();
    applyTheme(root.getAttribute("data-theme") || "light");
    initThemeButtons();
    initLoader();
    initNavbarEffects();
    initToasts();
    initNewsletter();
    renderDynamicContent();
    initFilters();
    initQuickForms();
    initReveal();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
